(function($) {
    const loader = '<div class="loader"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: rgb(255, 255, 255); display: block; shape-rendering: auto;" width="200px" height="200px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid"><circle cx="50" cy="50" r="0" fill="none" stroke="#7dd641" stroke-width="2"> <animate attributeName="r" repeatCount="indefinite" dur="1s" values="0;40" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="0s"></animate> <animate attributeName="opacity" repeatCount="indefinite" dur="1s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="0s"></animate></circle><circle cx="50" cy="50" r="0" fill="none" stroke="#6ce3e8" stroke-width="2"> <animate attributeName="r" repeatCount="indefinite" dur="1s" values="0;40" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="-0.5s"></animate> <animate attributeName="opacity" repeatCount="indefinite" dur="1s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="-0.5s"></animate></circle></div>';

    $(document).on('click', '.js-upcoming-lessons', function(e) {
        e.preventDefault();

        let ajaxData = {
            action: 'get_future_lessons',
        };

        $.ajax({
            type: 'POST',
            url: frontendajax.ajaxurl, // admin-ajax.php
            data: ajaxData,
            beforeSend: function () {
                // what to do just after the form has been submitted
                $('.appointments-wrap').empty().append(loader);
            },
            success: function ( response ) {
                console.log(response);
                $('.appointments-wrap').append(response);

            },
            complete: function() {
                $('.appointments-wrap').find('.loader').remove();
            },
        })
    })

    $(document).on('click', '.js-previous-lessons', function(e) {
            e.preventDefault();

            console.log('js-previous-lessons');

            let ajaxData = {
                action: 'get_past_lessons',
            };

            $.ajax({
                type: 'POST',
                url: frontendajax.ajaxurl, // admin-ajax.php
                data: ajaxData,
                beforeSend: function () {
                    // what to do just after the form has been submitted
                    $('.appointments-wrap').empty().append(loader);
                },
                success: function ( response ) {
                    console.log(response);
                    $('.appointments-wrap').append(response);

            },
            complete: function() {
                $('.appointments-wrap').find('.loader').remove();
            },
        })
    })

})(window.jQuery)